# Git Trending

The goal of this project is to use ReactJS capabilities and its paradigms by creating a simple
Github trending page clone.
The fully functional code must be uploaded to GitHub. The work must be yours, no other person
should be directly or indirectly involved. After you complete the work please provide us the GitHub
link where we can download and assess the work.
